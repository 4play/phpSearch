<?php

namespace Fir\Middleware;

/**
 * Class UserSettings sets the default user settings when navigating for the first time on site
 */
class UserSettings {
    public function __construct() {}
}