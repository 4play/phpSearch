<?php
// Theme Name
$name = 'phpSearch';

// Theme Author
$author = 'phpSearch';

// Theme URL
$url = 'https://phpsearch.com/';

// Theme Version
$version = '5.1.0';