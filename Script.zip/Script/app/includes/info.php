<?php

define('SOFTWARE_NAME', 'phpSearch');
define('SOFTWARE_AUTHOR', 'phpSearch');
define('SOFTWARE_URL', 'https://phpsearch.com');
define('SOFTWARE_VERSION', '5.2.0');